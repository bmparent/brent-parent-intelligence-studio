# Local page package

This package contains the exact reviewed single-page export and editable project. It is not a paid template archive, order, receipt of payment, or verified commercial license. No hosting, domain, backend, form delivery, or CMS installation is included.

Document: 3d258d57-c62f-4b40-a61a-a702a43a8b58
Revision: 0
Snapshot SHA-256: 2e71ca49adc7960d559751c31c806a1aabef5db5edd7aa25a529618b12a34e32
Output: eidos-local-page-package-v1 (standalone HTML/CSS/JavaScript)

Retained reference only: switchboard / switchboard-developer-v1 / 1.0.3. Original archive SHA-256: e956fc2aad4f76ed0ff2c9aff71cdd6cfc202b0701da71c9bf9604e5264b00d5; bytes: 28560. License reference: eidos-commercial-developer-1.0, products/templates/switchboard/developer/LICENSE.txt. The original archive is not included or modified. Selecting this reference does not establish ownership or grant rights. Keep the original licensed source and its notices.

Eidos starter illustrations and renderer retain their existing rights; user uploads require your own rights. This local review grants no additional license. Do not relabel it as a paid family package.

Extract all files together and open index.html. Import project.json into Playground to resume editing; importing creates a working draft. The frozen package remains separate. SNAPSHOT.json identifies the reviewed document/revision; PACKAGE_MANIFEST.json hashes every other file, including the source and provenance. The separate download receipt hashes the complete ZIP (a manifest cannot hash itself). Purchase stays unavailable until server ownership, immutable snapshot/order binding, entitlement, and delivery are implemented and verified.
